package ejextras6poo;



public class G7ejercicioExtra6 {

    public static void main(String[] args) {
        Empleado empleado1 = new Empleado();
        empleado1.crearEmpleado();
        empleado1.calcular_aumento();
    }
    
}
